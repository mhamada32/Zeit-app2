import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/car_model.dart';
import '../models/oil_log_model.dart';
import '../services/database_service.dart';

class AppProvider extends ChangeNotifier {
  List<CarModel> _cars = [];
  List<OilLogModel> _logs = [];
  String? _activeCarId;
  int _warnThresholdKm = 500;

  List<CarModel> get cars => _cars;
  List<OilLogModel> get logs => _logs;
  int get warnThresholdKm => _warnThresholdKm;

  CarModel? get activeCar {
    if (_cars.isEmpty) return null;
    return _cars.firstWhere((c) => c.id == _activeCarId, orElse: () => _cars.first);
  }

  List<OilLogModel> logsForCar(String carId, {String? category}) {
    return _logs
        .where((l) => l.carId == carId && (category == null || l.category == category))
        .toList()
      ..sort((a, b) => b.dateTime.compareTo(a.dateTime));
  }

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _warnThresholdKm = prefs.getInt('zeit_warn_km') ?? 500;
    _activeCarId = prefs.getString('zeit_active_car');

    _cars = await DatabaseService.instance.getCars();
    _logs = await DatabaseService.instance.getLogs();

    if (_cars.isEmpty) {
      final defaultCar = CarModel(
        id: 'car_default',
        brand: 'سيتروين (Citroën)',
        model: 'C4 SpaceTourer (C4 Space Travel)',
        year: 2020,
        currentOdometer: 100000,
      );
      await addCar(defaultCar);
    } else if (_activeCarId == null) {
      _activeCarId = _cars.first.id;
    }
    notifyListeners();
  }

  Future<void> selectCar(String carId) async {
    _activeCarId = carId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('zeit_active_car', carId);
    notifyListeners();
  }

  Future<void> setWarnThreshold(int km) async {
    _warnThresholdKm = km;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('zeit_warn_km', km);
    notifyListeners();
  }

  Future<void> addCar(CarModel car) async {
    await DatabaseService.instance.upsertCar(car);
    _cars.add(car);
    await selectCar(car.id);
    notifyListeners();
  }

  Future<void> updateOdometer(String carId, int newOdometer) async {
    final idx = _cars.indexWhere((c) => c.id == carId);
    if (idx == -1) return;
    _cars[idx].currentOdometer = newOdometer;
    await DatabaseService.instance.upsertCar(_cars[idx]);
    notifyListeners();
  }

  Future<void> updateCarPhoto(String carId, String? photoPath) async {
    final idx = _cars.indexWhere((c) => c.id == carId);
    if (idx == -1) return;
    _cars[idx].photoPath = photoPath;
    await DatabaseService.instance.upsertCar(_cars[idx]);
    notifyListeners();
  }

  Future<void> deleteCar(String carId) async {
    await DatabaseService.instance.deleteCar(carId);
    _cars.removeWhere((c) => c.id == carId);
    _logs.removeWhere((l) => l.carId == carId);
    if (_activeCarId == carId && _cars.isNotEmpty) {
      await selectCar(_cars.first.id);
    }
    notifyListeners();
  }

  Future<void> addLog(OilLogModel log) async {
    await DatabaseService.instance.upsertLog(log);
    _logs.insert(0, log);
    final carIdx = _cars.indexWhere((c) => c.id == log.carId);
    if (carIdx != -1 && log.odometer > _cars[carIdx].currentOdometer) {
      _cars[carIdx].currentOdometer = log.odometer;
      await DatabaseService.instance.upsertCar(_cars[carIdx]);
    }
    notifyListeners();
  }

  Future<void> deleteLog(String logId) async {
    await DatabaseService.instance.deleteLog(logId);
    _logs.removeWhere((l) => l.id == logId);
    notifyListeners();
  }

  Future<void> restoreAll({
    required List<CarModel> cars,
    required List<OilLogModel> logs,
    required String? activeCarId,
    required int warnThresholdKm,
  }) async {
    await DatabaseService.instance.replaceAllData(cars, logs);
    _cars = cars;
    _logs = logs;
    await setWarnThreshold(warnThresholdKm);
    if (activeCarId != null && _cars.any((c) => c.id == activeCarId)) {
      await selectCar(activeCarId);
    } else if (_cars.isNotEmpty) {
      await selectCar(_cars.first.id);
    }
    notifyListeners();
  }
}
