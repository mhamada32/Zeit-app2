import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ZeitThemePalette {
  final String id;
  final String name;
  final Color headerBg;
  final Color headerAccent;
  final Color scaffoldBg;
  final Color cardBg;
  final Color textMain;
  final Color textMuted;
  final Color buttonBg;
  final Color buttonText;
  final Color navBg;
  final Brightness brightness;

  const ZeitThemePalette({
    required this.id,
    required this.name,
    required this.headerBg,
    required this.headerAccent,
    required this.scaffoldBg,
    required this.cardBg,
    required this.textMain,
    required this.textMuted,
    required this.buttonBg,
    required this.buttonText,
    required this.navBg,
    this.brightness = Brightness.light,
  });

  Map<String, dynamic> toMap() => {
        'headerBg': headerBg.value,
        'headerAccent': headerAccent.value,
        'scaffoldBg': scaffoldBg.value,
        'cardBg': cardBg.value,
        'textMain': textMain.value,
        'textMuted': textMuted.value,
        'buttonBg': buttonBg.value,
        'buttonText': buttonText.value,
        'navBg': navBg.value,
      };

  factory ZeitThemePalette.fromCustomMap(Map<String, dynamic> m) => ZeitThemePalette(
        id: 'custom',
        name: 'ثيم مخصص (تصميمك)',
        headerBg: Color((m['headerBg'] as int?) ?? 0xFF1E1B4B),
        headerAccent: Color((m['headerAccent'] as int?) ?? 0xFFFACC15),
        scaffoldBg: Color((m['scaffoldBg'] as int?) ?? 0xFFF5F3FF),
        cardBg: Color((m['cardBg'] as int?) ?? 0xFFFFFFFF),
        textMain: Color((m['textMain'] as int?) ?? 0xFF1E1B4B),
        textMuted: Color((m['textMuted'] as int?) ?? 0xFF6B7280),
        buttonBg: Color((m['buttonBg'] as int?) ?? 0xFF7C3AED),
        buttonText: Color((m['buttonText'] as int?) ?? 0xFFFFFFFF),
        navBg: Color((m['navBg'] as int?) ?? 0xFFFFFFFF),
        brightness: ThemeData.estimateBrightnessForColor(Color((m['scaffoldBg'] as int?) ?? 0xFFF5F3FF)),
      );
}

class ThemeProvider extends ChangeNotifier {
  static const Map<String, ZeitThemePalette> presetThemes = {
    'classic': ZeitThemePalette(
      id: 'classic',
      name: 'ذهبي كلاسيكي',
      headerBg: Color(0xFF0F172A),
      headerAccent: Color(0xFFFBBF24),
      scaffoldBg: Color(0xFFF8FAFC),
      cardBg: Color(0xFFFFFFFF),
      textMain: Color(0xFF0F172A),
      textMuted: Color(0xFF64748B),
      buttonBg: Color(0xFFF59E0B),
      buttonText: Color(0xFF020617),
      navBg: Color(0xFFFFFFFF),
    ),
    'dark': ZeitThemePalette(
      id: 'dark',
      name: 'الليلي الفاخر',
      headerBg: Color(0xFF020617),
      headerAccent: Color(0xFF38BDF8),
      scaffoldBg: Color(0xFF0B1120),
      cardBg: Color(0xFF111827),
      textMain: Color(0xFFF8FAFC),
      textMuted: Color(0xFF94A3B8),
      buttonBg: Color(0xFF0EA5E9),
      buttonText: Color(0xFF020617),
      navBg: Color(0xFF0F172A),
      brightness: Brightness.dark,
    ),
    'sport': ZeitThemePalette(
      id: 'sport',
      name: 'سبورت أحمر',
      headerBg: Color(0xFF18181B),
      headerAccent: Color(0xFFEF4444),
      scaffoldBg: Color(0xFFF4F4F5),
      cardBg: Color(0xFFFFFFFF),
      textMain: Color(0xFF18181B),
      textMuted: Color(0xFF71717A),
      buttonBg: Color(0xFFDC2626),
      buttonText: Color(0xFFFFFFFF),
      navBg: Color(0xFFFFFFFF),
    ),
    'ocean': ZeitThemePalette(
      id: 'ocean',
      name: 'أزرق ملكي',
      headerBg: Color(0xFF0C2340),
      headerAccent: Color(0xFF60A5FA),
      scaffoldBg: Color(0xFFF0F6FF),
      cardBg: Color(0xFFFFFFFF),
      textMain: Color(0xFF0F172A),
      textMuted: Color(0xFF64748B),
      buttonBg: Color(0xFF2563EB),
      buttonText: Color(0xFFFFFFFF),
      navBg: Color(0xFFFFFFFF),
    ),
    'emerald': ZeitThemePalette(
      id: 'emerald',
      name: 'زمردي عصري',
      headerBg: Color(0xFF064E3B),
      headerAccent: Color(0xFF34D399),
      scaffoldBg: Color(0xFFF0FDF4),
      cardBg: Color(0xFFFFFFFF),
      textMain: Color(0xFF064E3B),
      textMuted: Color(0xFF4B5563),
      buttonBg: Color(0xFF059669),
      buttonText: Color(0xFFFFFFFF),
      navBg: Color(0xFFFFFFFF),
    ),
  };

  String _themeId = 'classic';
  ZeitThemePalette _customPalette = ZeitThemePalette.fromCustomMap({});

  String get themeId => _themeId;
  ZeitThemePalette get customPalette => _customPalette;
  ZeitThemePalette get current => _themeId == 'custom' ? _customPalette : (presetThemes[_themeId] ?? presetThemes['classic']!);

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _themeId = prefs.getString('zeit_theme_id') ?? 'classic';
    final customJson = prefs.getString('zeit_custom_theme');
    if (customJson != null) {
      _customPalette = ZeitThemePalette.fromCustomMap(jsonDecode(customJson) as Map<String, dynamic>);
    }
    notifyListeners();
  }

  Future<void> setTheme(String id) async {
    _themeId = id;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('zeit_theme_id', id);
    notifyListeners();
  }

  Future<void> updateCustomPalette(ZeitThemePalette palette) async {
    _customPalette = palette;
    _themeId = 'custom';
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('zeit_theme_id', 'custom');
    await prefs.setString('zeit_custom_theme', jsonEncode(palette.toMap()));
    notifyListeners();
  }

  ThemeData buildThemeData() {
    final p = current;
    return ThemeData(
      useMaterial3: true,
      brightness: p.brightness,
      scaffoldBackgroundColor: p.scaffoldBg,
      cardColor: p.cardBg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: p.buttonBg,
        brightness: p.brightness,
        primary: p.buttonBg,
        surface: p.cardBg,
      ),
      textTheme: GoogleFonts.cairoTextTheme().apply(
        bodyColor: p.textMain,
        displayColor: p.textMain,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: p.headerBg,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: p.navBg,
      ),
    );
  }
}
