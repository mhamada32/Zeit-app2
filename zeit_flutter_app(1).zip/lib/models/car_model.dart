class CarModel {
  final String id;
  final String brand;
  final String model;
  final int year;
  int currentOdometer;
  String? photoPath;

  CarModel({
    required this.id,
    required this.brand,
    required this.model,
    required this.year,
    required this.currentOdometer,
    this.photoPath,
  });

  String get displayName => '${brand.split(' (').first} ${model.split(' (').first} ($year)';

  Map<String, dynamic> toMap() => {
        'id': id,
        'brand': brand,
        'model': model,
        'year': year,
        'currentOdometer': currentOdometer,
        'photoPath': photoPath,
      };

  factory CarModel.fromMap(Map<String, dynamic> map) => CarModel(
        id: map['id'] as String,
        brand: map['brand'] as String,
        model: map['model'] as String,
        year: (map['year'] as num).toInt(),
        currentOdometer: (map['currentOdometer'] as num).toInt(),
        photoPath: map['photoPath'] as String?,
      );
}
