class OilLogModel {
  final String id;
  final String carId;
  final String category; // 'engine' | 'gearbox'
  final int odometer;
  final String oilName;
  final String viscosity;
  final String specs;
  final int rangeKm;
  final int rangeMonths;
  final int nextOdometer;
  final DateTime dateTime;
  final bool oilFilter;
  final bool airFilter;
  final double cost;
  final String center;
  final String notes;

  OilLogModel({
    required this.id,
    required this.carId,
    required this.category,
    required this.odometer,
    required this.oilName,
    required this.viscosity,
    required this.specs,
    required this.rangeKm,
    required this.rangeMonths,
    required this.nextOdometer,
    required this.dateTime,
    this.oilFilter = true,
    this.airFilter = false,
    this.cost = 0,
    this.center = '',
    this.notes = '',
  });

  bool get isGearbox => category == 'gearbox';

  DateTime get dueDate => DateTime(
        dateTime.year,
        dateTime.month + rangeMonths,
        dateTime.day,
        dateTime.hour,
        dateTime.minute,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'carId': carId,
        'category': category,
        'odometer': odometer,
        'oilName': oilName,
        'viscosity': viscosity,
        'specs': specs,
        'rangeKm': rangeKm,
        'rangeMonths': rangeMonths,
        'nextOdometer': nextOdometer,
        'dateTime': dateTime.toIso8601String(),
        'oilFilter': oilFilter ? 1 : 0,
        'airFilter': airFilter ? 1 : 0,
        'cost': cost,
        'center': center,
        'notes': notes,
      };

  factory OilLogModel.fromMap(Map<String, dynamic> map) => OilLogModel(
        id: map['id'] as String,
        carId: map['carId'] as String,
        category: (map['category'] as String?) ?? 'engine',
        odometer: (map['odometer'] as num).toInt(),
        oilName: map['oilName'] as String,
        viscosity: map['viscosity'] as String,
        specs: (map['specs'] as String?) ?? '',
        rangeKm: (map['rangeKm'] as num).toInt(),
        rangeMonths: (map['rangeMonths'] as num?)?.toInt() ?? 6,
        nextOdometer: (map['nextOdometer'] as num).toInt(),
        dateTime: DateTime.tryParse(map['dateTime'] as String? ?? '') ?? DateTime.now(),
        oilFilter: map['oilFilter'] == 1 || map['oilFilter'] == true,
        airFilter: map['airFilter'] == 1 || map['airFilter'] == true,
        cost: (map['cost'] as num?)?.toDouble() ?? 0,
        center: (map['center'] as String?) ?? '',
        notes: (map['notes'] as String?) ?? '',
      );
}
