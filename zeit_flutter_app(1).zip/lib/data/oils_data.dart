class OilSpecOption {
  final String label;
  final int rangeKm;
  final int rangeMonths;

  const OilSpecOption({
    required this.label,
    required this.rangeKm,
    required this.rangeMonths,
  });
}

const Map<String, Map<String, List<OilSpecOption>>> kEngineOilsDatabase = {
  'توتال (TotalEnergies Quartz)': {
    '0W-20': [
      OilSpecOption(label: 'Quartz 9000 Future GF6 تخليقي بالكامل (API SP)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Quartz INEO Xtra First 0W-20 (PSA B71 2010)', rangeKm: 10000, rangeMonths: 12),
    ],
    '0W-30': [
      OilSpecOption(label: 'Quartz INEO First 0W-30 (معتمد لبيجو وسيتروين PSA B71 2312)', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-30': [
      OilSpecOption(label: 'Quartz INEO ECS 5W-30 (PSA B71 2290)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Quartz INEO MC3 5W-30 (ACEA C3)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Quartz 9000 Future NFC 5W-30', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-40': [
      OilSpecOption(label: 'Quartz 7000 5W-40 نصف تخليقي / تكنولوجيا تخليقية (API SN)', rangeKm: 7000, rangeMonths: 6),
      OilSpecOption(label: 'Quartz 9000 Energy 5W-40 تخليقي بالكامل (API SN/SP)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Quartz INEO MC3 5W-40', rangeKm: 10000, rangeMonths: 12),
    ],
    '10W-40': [OilSpecOption(label: 'Quartz 7000 10W-40 نصف تخليقي (API SN)', rangeKm: 5000, rangeMonths: 6)],
    '15W-40': [OilSpecOption(label: 'Quartz 5000 15W-40 معدني', rangeKm: 4000, rangeMonths: 6)],
    '20W-50': [OilSpecOption(label: 'Quartz 5000 / 4000 20W-50 معدني', rangeKm: 3000, rangeMonths: 6)],
  },
  'موبيل (Mobil)': {
    '0W-20': [OilSpecOption(label: 'Mobil 1 Advanced Fuel Economy 0W-20', rangeKm: 10000, rangeMonths: 12)],
    '0W-40': [OilSpecOption(label: 'Mobil 1 FS 0W-40 تخليقي بالكامل (API SP)', rangeKm: 10000, rangeMonths: 12)],
    '5W-30': [
      OilSpecOption(label: 'Mobil 1 ESP 5W-30 تخليقي بالكامل (Dexos2)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Mobil Super 3000 X1 Formula FE 5W-30', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-40': [
      OilSpecOption(label: 'Mobil Super 3000 X1 5W-40 تخليقي بالكامل', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Mobil 1 FS X2 5W-40', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-50': [OilSpecOption(label: 'Mobil 1 FS X1 5W-50 (Peak Life)', rangeKm: 10000, rangeMonths: 12)],
    '10W-40': [OilSpecOption(label: 'Mobil Super 2000 X1 10W-40 نصف تخليقي', rangeKm: 5000, rangeMonths: 6)],
    '15W-40': [OilSpecOption(label: 'Mobil Super 1000 15W-40 معدني', rangeKm: 3000, rangeMonths: 6)],
    '20W-50': [OilSpecOption(label: 'Mobil Super 1000 XHP 20W-50 معدني', rangeKm: 3000, rangeMonths: 6)],
  },
  'شل هيلكس (Shell Helix)': {
    '0W-20': [OilSpecOption(label: 'Shell Helix Ultra SP 0W-20 (PurePlus)', rangeKm: 10000, rangeMonths: 12)],
    '5W-30': [
      OilSpecOption(label: 'Shell Helix Ultra 5W-30 تخليقي بالكامل', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Shell Helix HX8 5W-30', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-40': [
      OilSpecOption(label: 'Shell Helix Ultra 5W-40 تخليقي بالكامل', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Shell Helix HX8 5W-40', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Shell Helix HX7 5W-40 نصف تخليقي', rangeKm: 7000, rangeMonths: 6),
    ],
    '10W-40': [OilSpecOption(label: 'Shell Helix HX7 10W-40 نصف تخليقي', rangeKm: 5000, rangeMonths: 6)],
    '15W-40': [OilSpecOption(label: 'Shell Helix HX5 15W-40 معدني منظف', rangeKm: 5000, rangeMonths: 6)],
    '20W-50': [OilSpecOption(label: 'Shell Helix HX3 20W-50 معدني', rangeKm: 3000, rangeMonths: 6)],
  },
  'كاسترول (Castrol)': {
    '0W-20': [OilSpecOption(label: 'Castrol EDGE 0W-20', rangeKm: 10000, rangeMonths: 12)],
    '5W-30': [
      OilSpecOption(label: 'Castrol EDGE 5W-30 LL / C3', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Castrol MAGNATEC 5W-30 Start-Stop', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-40': [
      OilSpecOption(label: 'Castrol EDGE 5W-40 تخليقي بالكامل', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Castrol MAGNATEC 5W-40', rangeKm: 10000, rangeMonths: 12),
    ],
    '10W-40': [OilSpecOption(label: 'Castrol MAGNATEC 10W-40 نصف تخليقي', rangeKm: 5000, rangeMonths: 6)],
    '20W-50': [OilSpecOption(label: 'Castrol GTX 20W-50 معدني', rangeKm: 3000, rangeMonths: 6)],
  },
  'ليكوي مولي (Liqui Moly)': {
    '0W-20': [OilSpecOption(label: 'Special Tec AA 0W-20 / Top Tec 6600', rangeKm: 10000, rangeMonths: 12)],
    '5W-30': [
      OilSpecOption(label: 'Top Tec 4200 / 4300 / 4600 5W-30', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Molygen New Generation 5W-30', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-40': [
      OilSpecOption(label: 'Leichtlauf High Tech 5W-40 (API SP)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Synthoil High Tech 5W-40 (PAO)', rangeKm: 10000, rangeMonths: 12),
      OilSpecOption(label: 'Molygen New Generation 5W-40', rangeKm: 10000, rangeMonths: 12),
    ],
    '10W-40': [OilSpecOption(label: 'MoS2 Leichtlauf 10W-40 (بالموليبدينوم)', rangeKm: 7000, rangeMonths: 6)],
    '20W-50': [OilSpecOption(label: 'Touring High Tech 20W-50', rangeKm: 4000, rangeMonths: 6)],
  },
  'موتول (Motul)': {
    '5W-30': [OilSpecOption(label: '8100 X-clean EFE 5W-30', rangeKm: 10000, rangeMonths: 12)],
    '5W-40': [OilSpecOption(label: '8100 X-cess gen2 5W-40', rangeKm: 10000, rangeMonths: 12)],
    '10W-40': [OilSpecOption(label: '6100 Synergie+ 10W-40', rangeKm: 7000, rangeMonths: 6)],
  },
  'فالفولين / وولف / إلف / فوكس / إكسادو / رايفينول': {
    '5W-30': [
      OilSpecOption(label: 'Valvoline SynPower / Wolf OfficialTech / Fuchs Titan GT1 / Ravenol VMP', rangeKm: 10000, rangeMonths: 12),
    ],
    '5W-40': [
      OilSpecOption(label: 'Valvoline SynPower / Elf Evolution 900 / XADO 5W-40 / Ravenol VST', rangeKm: 10000, rangeMonths: 12),
    ],
    '10W-40': [
      OilSpecOption(label: 'Valvoline MaxLife / Wolf GuardTech / Elf Evolution 700 / XADO 10W-40', rangeKm: 5000, rangeMonths: 6),
    ],
  },
  'التعاون / مصر للبترول / الوطنية': {
    '5W-40': [OilSpecOption(label: 'تخليقي بالكامل 5W-40 (API SN)', rangeKm: 10000, rangeMonths: 12)],
    '10W-40': [OilSpecOption(label: 'نصف تخليقي 10W-40', rangeKm: 5000, rangeMonths: 6)],
    '15W-40': [OilSpecOption(label: 'معدني 15W-40', rangeKm: 4000, rangeMonths: 6)],
    '20W-50': [OilSpecOption(label: 'معدني 20W-50', rangeKm: 3000, rangeMonths: 6)],
  },
  'زيوت الوكالات الأصلية (OEM)': {
    '0W-20': [OilSpecOption(label: 'Toyota / Honda / Nissan Genuine 0W-20', rangeKm: 10000, rangeMonths: 12)],
    '5W-30': [OilSpecOption(label: 'GM Dexos2 / Toyota / Mercedes / BMW / VW 5W-30', rangeKm: 10000, rangeMonths: 12)],
    '5W-40': [OilSpecOption(label: 'Mercedes MB 229.5 / VW 502 / BMW LL-01 5W-40', rangeKm: 10000, rangeMonths: 12)],
  },
};

const Map<String, Map<String, List<OilSpecOption>>> kGearboxOilsDatabase = {
  'أوتوماتيك (ATF)': {
    'موبيل (Mobil)': [
      OilSpecOption(label: 'Mobil ATF 320 (Dexron III)', rangeKm: 40000, rangeMonths: 24),
      OilSpecOption(label: 'Mobil ATF LT 71141 (بيجو/سيتروين AL4)', rangeKm: 60000, rangeMonths: 36),
      OilSpecOption(label: 'Mobil 1 Synthetic ATF (Dexron VI)', rangeKm: 60000, rangeMonths: 36),
    ],
    'توتال (TotalEnergies)': [
      OilSpecOption(label: 'Total Fluidmatic MV LV (Dexron VI / EAT6-EAT8)', rangeKm: 60000, rangeMonths: 36),
      OilSpecOption(label: 'Total Fluide G3 (Dexron III)', rangeKm: 40000, rangeMonths: 24),
    ],
    'شل / ليكوي مولي / أصلي (OEM)': [
      OilSpecOption(label: 'Shell Spirax S6 / Liqui Moly Top Tec ATF 1800 / Toyota WS / Hyundai SP-IV', rangeKm: 60000, rangeMonths: 36),
    ],
  },
  'فتيس CVT': {
    'موبيل / توتال / ليكوي مولي / موتول': [
      OilSpecOption(label: 'Mobil CVTF / Total CVT MV / Liqui Moly ATF 1400 / Motul Multi CVTF', rangeKm: 50000, rangeMonths: 36),
    ],
    'أصلي وكالة (OEM)': [
      OilSpecOption(label: 'Nissan NS-2 / NS-3 / Toyota CVT FE / Honda HCF-2', rangeKm: 50000, rangeMonths: 36),
    ],
  },
  'فتيس دبل كلاتش (DCT / DSG)': {
    'ليكوي مولي / موتول / توتال / OEM': [
      OilSpecOption(label: 'Liqui Moly Dual Clutch 8100 / Motul DCTF / VW DSG G052 182', rangeKm: 60000, rangeMonths: 36),
    ],
  },
  'فتيس مانيوال (Manual MTF)': {
    'موبيل / شل / توتال / ليكوي مولي': [
      OilSpecOption(label: '75W-80 / 75W-90 / 80W-90 GL-4', rangeKm: 50000, rangeMonths: 36),
    ],
  },
};
