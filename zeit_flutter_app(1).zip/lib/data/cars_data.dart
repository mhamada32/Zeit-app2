const Map<String, List<String>> kWorldCarsDatabase = {
  'سيتروين (Citroën)': [
    'C4 SpaceTourer (C4 Space Travel)', 'Grand C4 SpaceTourer', 'C4 Picasso', 'Grand C4 Picasso',
    'C4', 'C4X', 'C4 Cactus', 'C-Elysée (سي إليزيه)', 'C3', 'C3 Aircross', 'C5', 'C5 Aircross',
    'C5X', 'C1', 'C2', 'C6', 'C8', 'Berlingo', 'Xsara', 'Saxo', 'DS3', 'DS4', 'DS5', 'DS7'
  ],
  'دايو (Daewoo)': [
    'لاسيتي (Lacetti)', 'لانوس (Lanos)', 'لانوس 2', 'نوبيرا 1 (Nubira I)', 'نوبيرا 2 (Nubira II)',
    'جولييت (Juliet)', 'إسبيرو (Espero)', 'سيلو (Cielo)', 'ليجانزا (Leganza)', 'ماتيز (Matiz)',
    'رايسر (Racer)', 'كالوس (Kalos)', 'توسكا (Tosca)', 'جينترا (Gentra)', 'داماس (Damas)'
  ],
  'تويوتا (Toyota)': [
    'كورولا (Corolla)', 'كورولا كروس', 'ياريس (Yaris)', 'كامري (Camry)', 'فورتشنر (Fortuner)',
    'راف 4 (RAV4)', 'لاندكروزر (Land Cruiser)', 'برادو (Prado)', 'هايلكس (Hilux)', 'C-HR',
    'راش (Rush)', 'أفانزا (Avanza)', 'بيلتا (Belta)', 'روميون (Rumion)', 'ستارلت', 'بريوس', 'إنوفا', 'هايس'
  ],
  'هيونداي (Hyundai)': [
    'إلنترا (Elantra)', 'أكسنت (Accent)', 'توسان (Tucson)', 'فيرنا (Verna)', 'إكسيل (Excel)',
    'ماتريكس (Matrix)', 'أفانتي (Avante)', 'سوناتا (Sonata)', 'سانتا في (Santa Fe)', 'كريتا (Creta)',
    'بايون (Bayon)', 'كونا (Kona)', 'باليسايد', 'جيتز', 'أتوس', 'i10', 'i20', 'i30', 'ix35', 'H1'
  ],
  'كيا (Kia)': [
    'سيراتو (Cerato / K3)', 'سبورتاج (Sportage)', 'بيكانتو (Picanto)', 'ريو (Rio)', 'كارينز (Carens)',
    'سول (Soul)', 'سورينتو (Sorento)', 'أوبتيما / K5', 'سيلتوس', 'إكسيد (XCeed)', 'نيرو', 'كارنيفال',
    'سيفيا', 'شوما', 'سبكترا', 'برايد', 'بيجاس', 'EV6'
  ],
  'شيفروليه (Chevrolet)': [
    'أوبترا (Optra)', 'لاسيتي (Lacetti)', 'لانوس (Lanos)', 'أفيو (Aveo)', 'كروز (Cruze)',
    'كابتيفا (Captiva)', 'سبارك (Spark)', 'ماليبو', 'إكوينوكس', 'تاهو', 'سوبربان', 'كامارو', 'N300', 'دبابة'
  ],
  'نيسان (Nissan)': [
    'صني (Sunny)', 'سنترا (Sentra)', 'قشقاي (Qashqai)', 'جوك (Juke)', 'تيدا (Tiida)',
    'إكس تريل (X-Trail)', 'باترول', 'باثفايندر', 'كيكس', 'ألتيما', 'ماكسيما', 'ميكرا', 'نافارا'
  ],
  'فيات (Fiat)': [
    'تيبو (Tipo)', 'شاهين (Shahin)', '128', '131', 'بونتو (Punto)', 'سيينا', 'بترا', 'أونو',
    'تمبرا', '500', '500X', 'باندا', 'دوبلو', 'فيورينو', 'لينيا'
  ],
  'لادا (Lada)': ['جرانتا (Granta)', '2107', '2105', '2104', '2110', 'نيفا (Niva)', 'فيستا', 'سمارا'],
  'بيجو (Peugeot)': ['301', '504', '505', '508', '3008', '2008', '5008', '208', '308', '408', '405', '406', '307', 'بارتنر', 'ريفتر'],
  'رينو (Renault)': ['لوجان (Logan)', 'ميجان (Megane)', 'داستر (Duster)', 'سانديرو', 'ستيب واي', 'كادجار', 'أوسترال', 'تاليانت', 'كليو', 'فلونس', 'سينيك', 'كانجو'],
  'سوزوكي (Suzuki)': ['سويفت (Swift)', 'ديزاير (Dzire)', 'ألتو', 'ماروتي', 'سياز', 'إسبريسو', 'إرتيجا', 'فيتارا', 'جيمني', 'بالينو', 'فرونكس'],
  'ميتسوبيشي (Mitsubishi)': ['لانسر (Lancer)', 'إكليبس كروس', 'إكسباندر', 'أتراج', 'ميراج', 'أوتلاندر', 'باجيرو', 'ASX', 'L200'],
  'إم جي (MG)': ['MG 5', 'MG 6', 'MG ZS', 'MG HS', 'MG RX5', 'MG GT', 'MG 4', 'MG One'],
  'شيري (Chery)': ['أريزو 5', 'تيجو 3', 'تيجو 4 برو', 'تيجو 7', 'تيجو 7 برو', 'تيجو 8', 'إنفي'],
  'بي واي دي (BYD)': ['F3', 'L3', 'S5', 'سنج بلس', 'أتو 3', 'دولفين', 'سيل'],
  'جيلي (Geely)': ['إمجراند 7', 'كول راي', 'ستار راي', 'أوكافانجو', 'GX3 Pro', 'باندينو'],
  'شانجان / هافال / جيتور': ['Changan Alsvin', 'Changan CS55 Plus', 'Changan UNI-T', 'Haval Jolion', 'Haval H6', 'Jetour X70', 'Jetour Dashing', 'Jetour T2'],
  'بروتون / إسبيرانزا / بريليانس': ['Proton Saga', 'Proton Gen-2', 'Speranza A516', 'Speranza A113', 'Speranza Tiggo', 'Brilliance FRV', 'Brilliance V5'],
  'سيات (Seat)': ['إبيزا', 'ليون', 'أرونا', 'أتيكا', 'تاراكو', 'توليدو', 'Cupra Formentor'],
  'أوبل (Opel)': ['أسترا', 'كورسا', 'إنسيجنيا', 'كروس لاند', 'جراند لاند', 'موكا', 'فيكترا', 'زافيرا'],
  'سكودا (Skoda)': ['أوكتافيا', 'كودياك', 'كاروك', 'كاميك', 'فابيا', 'سكالا', 'سوبيرب', 'رابيد', 'فيليشيا'],
  'فولكس فاجن (Volkswagen)': ['جولف', 'باسات', 'تيجوان', 'طوارق', 'تي روك', 'جيتا', 'بولو', 'توران', 'كادي', 'ID.4'],
  'مرسيدس (Mercedes-Benz)': ['A-Class', 'B-Class', 'C-Class', 'E-Class', 'S-Class', 'CLA', 'GLA', 'GLC', 'GLE', 'G-Class', '190E / W124'],
  'بي إم دبليو (BMW)': ['1 Series', '2 Series', '3 Series', '4 Series', '5 Series', '7 Series', 'X1', 'X3', 'X5', 'X6'],
  'أودي / فولفو / بورش': ['Audi A3', 'Audi A4', 'Audi Q3', 'Audi Q5', 'Volvo XC40', 'Volvo XC60', 'Porsche Cayenne', 'Porsche Macan'],
  'هوندا / مازدا / سوبارو / دايهاتسو': ['Honda Civic', 'Honda Accord', 'Honda CR-V', 'Mazda 3', 'Mazda CX-5', 'Subaru XV', 'Subaru Impreza', 'Daihatsu Terios', 'Daihatsu Sirion'],
  'فورد / جيب / لاند روفر / لكزس': ['Ford Focus', 'Ford Kuga', 'Ford Explorer', 'Jeep Renegade', 'Jeep Grand Cherokee', 'Jeep Wrangler', 'Range Rover', 'Defender', 'Lexus ES', 'Lexus RX'],
};

List<int> get kCarYears => List<int>.generate(2026 - 1980 + 1, (i) => 2026 - i);
