import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/car_model.dart';
import '../models/oil_log_model.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._();
  DatabaseService._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'zeit_app.db');
    _db = await openDatabase(
      path,
      version: 2,
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 2) {
          await db.execute('ALTER TABLE cars ADD COLUMN photoPath TEXT');
        }
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE cars (
            id TEXT PRIMARY KEY,
            brand TEXT NOT NULL,
            model TEXT NOT NULL,
            year INTEGER NOT NULL,
            currentOdometer INTEGER NOT NULL,
            photoPath TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE oil_logs (
            id TEXT PRIMARY KEY,
            carId TEXT NOT NULL,
            category TEXT NOT NULL,
            odometer INTEGER NOT NULL,
            oilName TEXT NOT NULL,
            viscosity TEXT NOT NULL,
            specs TEXT,
            rangeKm INTEGER NOT NULL,
            rangeMonths INTEGER NOT NULL,
            nextOdometer INTEGER NOT NULL,
            dateTime TEXT NOT NULL,
            oilFilter INTEGER NOT NULL,
            airFilter INTEGER NOT NULL,
            cost REAL NOT NULL,
            center TEXT,
            notes TEXT
          )
        ''');
      },
    );
    return _db!;
  }

  Future<List<CarModel>> getCars() async {
    final db = await database;
    final rows = await db.query('cars');
    return rows.map(CarModel.fromMap).toList();
  }

  Future<void> upsertCar(CarModel car) async {
    final db = await database;
    await db.insert('cars', car.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteCar(String carId) async {
    final db = await database;
    await db.delete('cars', where: 'id = ?', whereArgs: [carId]);
    await db.delete('oil_logs', where: 'carId = ?', whereArgs: [carId]);
  }

  Future<List<OilLogModel>> getLogs() async {
    final db = await database;
    final rows = await db.query('oil_logs', orderBy: 'dateTime DESC');
    return rows.map(OilLogModel.fromMap).toList();
  }

  Future<void> upsertLog(OilLogModel log) async {
    final db = await database;
    await db.insert('oil_logs', log.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteLog(String logId) async {
    final db = await database;
    await db.delete('oil_logs', where: 'id = ?', whereArgs: [logId]);
  }

  Future<void> replaceAllData(List<CarModel> cars, List<OilLogModel> logs) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('oil_logs');
      await txn.delete('cars');
      for (final c in cars) {
        await txn.insert('cars', c.toMap());
      }
      for (final l in logs) {
        await txn.insert('oil_logs', l.toMap());
      }
    });
  }
}
