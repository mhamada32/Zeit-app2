import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import '../models/car_model.dart';
import '../models/oil_log_model.dart';
import '../providers/app_provider.dart';
import '../providers/theme_provider.dart';

class BackupService {
  /// Opens the native Android / iOS File Browser to choose where to save the full backup
  /// including cars, logs, notification threshold, active theme, and custom theme colors.
  static Future<String?> exportBackup(AppProvider app, ThemeProvider theme) async {
    final payload = {
      'appName': 'زيت',
      'designer': 'د/ محمد حماده',
      'backupVersion': 2,
      'exportedAt': DateTime.now().toIso8601String(),
      'activeCarId': app.activeCar?.id,
      'warnThresholdKm': app.warnThresholdKm,
      'theme': theme.themeId,
      'customTheme': theme.customPalette.toMap(),
      'cars': app.cars.map((c) => c.toMap()).toList(),
      'logs': app.logs.map((l) => l.toMap()).toList(),
    };

    final jsonString = const JsonEncoder.withIndent('  ').convert(payload);
    final bytes = Uint8List.fromList(utf8.encode(jsonString));
    final dateTag = DateTime.now().toIso8601String().substring(0, 10);

    final savedPath = await FilePicker.platform.saveFile(
      dialogTitle: 'اختر مكان حفظ النسخة الاحتياطية - تطبيق زيت',
      fileName: 'zeit_backup_$dateTag.json',
      type: FileType.custom,
      allowedExtensions: ['json'],
      bytes: bytes,
    );

    if (savedPath != null && Platform.isWindows || savedPath != null && Platform.isMacOS || savedPath != null && Platform.isLinux) {
      await File(savedPath).writeAsBytes(bytes);
    }
    return savedPath;
  }

  /// Opens the native File Browser to pick a JSON backup and restores all data + theme settings.
  static Future<bool> importBackup(AppProvider app, ThemeProvider theme) async {
    final result = await FilePicker.platform.pickFiles(
      dialogTitle: 'اختر ملف النسخة الاحتياطية',
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return false;

    final file = result.files.first;
    final content = file.bytes != null
        ? utf8.decode(file.bytes!)
        : await File(file.path!).readAsString();

    final decoded = jsonDecode(content) as Map<String, dynamic>;
    final cars = (decoded['cars'] as List).map((e) => CarModel.fromMap(e as Map<String, dynamic>)).toList();
    final logs = (decoded['logs'] as List).map((e) => OilLogModel.fromMap(e as Map<String, dynamic>)).toList();

    await app.restoreAll(
      cars: cars,
      logs: logs,
      activeCarId: decoded['activeCarId'] as String?,
      warnThresholdKm: (decoded['warnThresholdKm'] as num?)?.toInt() ?? 500,
    );

    if (decoded['customTheme'] is Map<String, dynamic>) {
      final ct = ZeitThemePalette.fromCustomMap(decoded['customTheme'] as Map<String, dynamic>);
      await theme.updateCustomPalette(ct);
    }
    final restoredTheme = (decoded['theme'] as String?) ?? 'classic';
    await theme.setTheme(restoredTheme);
    return true;
  }
}
