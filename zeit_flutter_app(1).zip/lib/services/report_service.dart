import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/car_model.dart';
import '../models/oil_log_model.dart';

class ReportService {
  static Future<void> exportReport({
    required String format, // 'pdf' | 'html' | 'csv'
    required List<CarModel> cars,
    required List<OilLogModel> logs,
  }) async {
    final dateStamp = DateFormat('yyyy-MM-dd').format(DateTime.now());

    if (format == 'pdf') {
      final doc = pw.Document();
      final totalCost = logs.fold<double>(0, (s, l) => s + l.cost);
      doc.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          build: (ctx) => [
            pw.Header(
              level: 0,
              child: pw.Text('Zeit Oil Report - Dr. Mohamed Hamada ($dateStamp)'),
            ),
            pw.Text('Cars: ${cars.length} | Logs: ${logs.length} | Total Cost: ${totalCost.toStringAsFixed(0)} EGP'),
            pw.SizedBox(height: 12),
            pw.TableHelper.fromTextArray(
              headers: ['Car', 'Type', 'Oil / Viscosity', 'Odometer', 'Next KM', 'Cost'],
              data: logs.map((l) {
                final car = cars.firstWhere((c) => c.id == l.carId, orElse: () => cars.first);
                return [
                  '${car.brand} ${car.model} (${car.year})',
                  l.isGearbox ? 'Gearbox' : 'Engine',
                  '${l.oilName} (${l.viscosity})',
                  '${l.odometer}',
                  '${l.nextOdometer}',
                  '${l.cost.toStringAsFixed(0)}',
                ];
              }).toList(),
            ),
          ],
        ),
      );
      await Printing.layoutPdf(onLayout: (_) async => doc.save());
      return;
    }

    if (format == 'csv') {
      String esc(dynamic v) => '"${v.toString().replaceAll('"', '""')}"';
      final rows = <String>[
        ['السيارة', 'سنة الصنع', 'الفئة', 'الزيت', 'اللزوجة', 'المواصفات', 'العداد', 'القادم', 'التاريخ', 'التكلفة', 'ملاحظات'].map(esc).join(','),
      ];
      for (final l in logs) {
        final car = cars.firstWhere((c) => c.id == l.carId, orElse: () => cars.first);
        rows.add([
          '${car.brand} ${car.model}', car.year, l.isGearbox ? 'زيت فتيس' : 'زيت محرك',
          l.oilName, l.viscosity, l.specs, l.odometer, l.nextOdometer,
          DateFormat('yyyy-MM-dd HH:mm').format(l.dateTime), l.cost, '${l.center} ${l.notes}',
        ].map(esc).join(','));
      }
      final csvBytes = Uint8List.fromList(utf8.encode('\uFEFF${rows.join('\r\n')}'));
      await FilePicker.platform.saveFile(
        dialogTitle: 'حفظ التقرير بصيغة CSV',
        fileName: 'zeit_report_$dateStamp.csv',
        type: FileType.custom,
        allowedExtensions: ['csv'],
        bytes: csvBytes,
      );
      return;
    }

    // HTML export
    final totalCost = logs.fold<double>(0, (s, l) => s + l.cost);
    final rowsHtml = logs.map((l) {
      final car = cars.firstWhere((c) => c.id == l.carId, orElse: () => cars.first);
      return '<tr><td>${car.displayName}</td><td>${l.isGearbox ? "زيت فتيس" : "زيت محرك"}</td><td>${l.oilName} (${l.viscosity})</td><td>${l.odometer}</td><td>${l.nextOdometer}</td><td>${l.cost.toStringAsFixed(0)} ج.م</td></tr>';
    }).join();

    final html = '''<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تقرير تطبيق زيت</title>
    <style>body{font-family:Tahoma,sans-serif;padding:24px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #cbd5e1;padding:8px;text-align:right}th{background:#0f172a;color:#fbbf24}</style>
    </head><body><h1>تقرير تطبيق زيت — تصميم د/ محمد حماده</h1>
    <p>التاريخ: $dateStamp • السيارات: ${cars.length} • السجلات: ${logs.length} • إجمالي التكلفة: ${totalCost.toStringAsFixed(0)} ج.م</p>
    <table><thead><tr><th>السيارة</th><th>الفئة</th><th>الزيت</th><th>العداد</th><th>القادم</th><th>التكلفة</th></tr></thead><tbody>$rowsHtml</tbody></table>
    </body></html>''';

    await FilePicker.platform.saveFile(
      dialogTitle: 'حفظ التقرير بصيغة HTML',
      fileName: 'zeit_report_$dateStamp.html',
      type: FileType.custom,
      allowedExtensions: ['html'],
      bytes: Uint8List.fromList(utf8.encode(html)),
    );
  }
}
