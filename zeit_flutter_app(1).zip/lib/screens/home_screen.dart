import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../data/cars_data.dart';
import '../data/oils_data.dart';
import '../models/car_model.dart';
import '../models/oil_log_model.dart';
import '../providers/app_provider.dart';
import '../providers/theme_provider.dart';
import '../services/backup_service.dart';
import '../services/report_service.dart';
import 'camera_ocr_screen.dart';
import 'custom_theme_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tabIndex = 0;

  // Log form state
  String _logCategory = 'engine';
  final _logOdoCtrl = TextEditingController();
  final _rangeKmCtrl = TextEditingController(text: '10000');
  final _extraSpecsCtrl = TextEditingController();
  final _costCtrl = TextEditingController();
  final _centerCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  int _rangeMonths = 12;
  bool _oilFilter = true;
  bool _airFilter = false;
  DateTime _selectedDateTime = DateTime.now();

  String _oilBrand = kEngineOilsDatabase.keys.first;
  String _oilVisc = kEngineOilsDatabase.values.first.keys.first;
  int _oilSpecIdx = 0;

  String _gbType = kGearboxOilsDatabase.keys.first;
  String _gbBrand = kGearboxOilsDatabase.values.first.keys.first;
  int _gbSpecIdx = 0;

  Future<String?> _pickCarPhoto(BuildContext ctx) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: ctx,
      builder: (c) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('التقاط صورة بالكاميرا'),
              onTap: () => Navigator.pop(c, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('اختيار من الاستوديو'),
              onTap: () => Navigator.pop(c, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return null;
    final picked = await ImagePicker().pickImage(source: source, imageQuality: 80, maxWidth: 800);
    return picked?.path;
  }

  Future<void> _confirmDeleteCar(AppProvider app, CarModel car) async {
    if (app.cars.length <= 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يمكن حذف آخر سيارة — أضف سيارة أخرى أولاً')),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف السيارة'),
        content: Text('هل أنت متأكد من حذف ${car.displayName} وجميع سجلاتها؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await app.deleteCar(car.id);
    }
  }

  Future<void> _openCameraFor(TextEditingController ctrl, {bool updateCarImmediately = false}) async {
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(builder: (_) => const CameraOcrScreen()),
    );
    if (result != null && mounted) {
      ctrl.text = result.toString();
      if (updateCarImmediately) {
        final car = context.read<AppProvider>().activeCar;
        if (car != null) await context.read<AppProvider>().updateOdometer(car.id, result);
      }
      setState(() {});
    }
  }

  void _openReportDialog(BuildContext context) {
    final app = context.read<AppProvider>();
    String selectedCar = 'all';
    String selectedFormat = 'pdf';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlgState) => AlertDialog(
          title: const Text('إنشاء تقرير شامل'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: selectedCar,
                decoration: const InputDecoration(labelText: 'نطاق التقرير'),
                items: [
                  DropdownMenuItem(value: 'all', child: Text('كل السيارات (${app.cars.length})')),
                  ...app.cars.map((c) => DropdownMenuItem(value: c.id, child: Text(c.displayName))),
                ],
                onChanged: (v) => setDlgState(() => selectedCar = v ?? 'all'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: selectedFormat,
                decoration: const InputDecoration(labelText: 'صيغة الملف'),
                items: const [
                  DropdownMenuItem(value: 'pdf', child: Text('PDF للطباعة والحفظ')),
                  DropdownMenuItem(value: 'html', child: Text('HTML تقرير منسق')),
                  DropdownMenuItem(value: 'csv', child: Text('CSV جدول إكسل')),
                ],
                onChanged: (v) => setDlgState(() => selectedFormat = v ?? 'pdf'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                final cars = selectedCar == 'all' ? app.cars : app.cars.where((c) => c.id == selectedCar).toList();
                final carIds = cars.map((c) => c.id).toSet();
                final logs = app.logs.where((l) => carIds.contains(l.carId)).toList();
                await ReportService.exportReport(format: selectedFormat, cars: cars, logs: logs);
              },
              child: const Text('حفظ وتصدير'),
            ),
          ],
        ),
      ),
    );
  }

  void _openAddCarDialog(BuildContext context) {
    String brand = kWorldCarsDatabase.keys.first;
    String model = kWorldCarsDatabase[brand]!.first;
    int year = 2020;
    final odoCtrl = TextEditingController();
    bool manual = false;
    final mBrand = TextEditingController();
    final mModel = TextEditingController();
    String? pickedPhotoPath;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          title: const Text('إضافة سيارة جديدة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SwitchListTile(
                  title: const Text('إدخال يدوي'),
                  value: manual,
                  onChanged: (v) => setDlg(() => manual = v),
                ),
                if (!manual) ...[
                  DropdownButtonFormField<String>(
                    value: brand,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'الماركة'),
                    items: kWorldCarsDatabase.keys.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
                    onChanged: (v) => setDlg(() {
                      brand = v!;
                      model = kWorldCarsDatabase[brand]!.first;
                    }),
                  ),
                  DropdownButtonFormField<String>(
                    value: model,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'الموديل'),
                    items: kWorldCarsDatabase[brand]!.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                    onChanged: (v) => setDlg(() => model = v!),
                  ),
                ] else ...[
                  TextField(controller: mBrand, decoration: const InputDecoration(labelText: 'الماركة')),
                  TextField(controller: mModel, decoration: const InputDecoration(labelText: 'الموديل')),
                ],
                DropdownButtonFormField<int>(
                  value: year,
                  decoration: const InputDecoration(labelText: 'سنة الصنع (1980 - 2026)'),
                  items: kCarYears.map((y) => DropdownMenuItem(value: y, child: Text('$y'))).toList(),
                  onChanged: (v) => setDlg(() => year = v!),
                ),
                TextField(
                  controller: odoCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'العداد الحالي (كم)'),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    if (pickedPhotoPath != null && File(pickedPhotoPath!).existsSync())
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(File(pickedPhotoPath!), width: 48, height: 48, fit: BoxFit.cover),
                      ),
                    if (pickedPhotoPath != null) const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.add_a_photo),
                        label: Text(pickedPhotoPath == null ? 'إضافة صورة السيارة' : 'تغيير الصورة'),
                        onPressed: () async {
                          final p = await _pickCarPhoto(ctx);
                          if (p != null) setDlg(() => pickedPhotoPath = p);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                final car = CarModel(
                  id: 'car_${DateTime.now().millisecondsSinceEpoch}',
                  brand: manual ? mBrand.text.trim() : brand,
                  model: manual ? mModel.text.trim() : model,
                  year: year,
                  currentOdometer: int.tryParse(odoCtrl.text.trim()) ?? 0,
                  photoPath: pickedPhotoPath,
                );
                await context.read<AppProvider>().addCar(car);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final themeProv = context.watch<ThemeProvider>();
    final palette = themeProv.current;
    final car = app.activeCar;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('زيت', style: TextStyle(color: palette.headerAccent, fontWeight: FontWeight.w900, fontSize: 22)),
            const Text('تصميم: د/ محمد حماده', style: TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'تقرير شامل',
            icon: const Icon(Icons.description_outlined),
            onPressed: () => _openReportDialog(context),
          ),
          PopupMenuButton<String>(
            tooltip: 'اختيار الثيم',
            icon: Icon(Icons.palette, color: palette.headerAccent),
            onSelected: (id) {
              if (id == 'custom') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomThemeScreen()));
              } else {
                themeProv.setTheme(id);
              }
            },
            itemBuilder: (_) => [
              ...ThemeProvider.presetThemes.values.map(
                (t) => PopupMenuItem(value: t.id, child: Text(t.name)),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(value: 'custom', child: Text('ثيم مخصص (تصميمك)')),
            ],
          ),
        ],
      ),
      body: car == null
          ? const Center(child: CircularProgressIndicator())
          : IndexedStack(
              index: _tabIndex,
              children: [
                _buildDashboard(app, car),
                _buildLogTab(app, car),
                _buildHistoryTab(app),
                _buildSettingsTab(app, themeProv),
              ],
            ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'تسجيل غيار'),
          NavigationDestination(icon: Icon(Icons.directions_car), label: 'السيارات والسجل'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }

  Widget _buildDashboard(AppProvider app, CarModel car) {
    final engLatest = (app.logsForCar(car.id, category: 'engine').isEmpty ? null : app.logsForCar(car.id, category: 'engine').first);
    final gbLatest = (app.logsForCar(car.id, category: 'gearbox').isEmpty ? null : app.logsForCar(car.id, category: 'gearbox').first);
    final odoCtrl = TextEditingController(text: car.currentOdometer.toString());

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (car.photoPath != null && File(car.photoPath!).existsSync()) ...[
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.file(File(car.photoPath!), height: 150, width: double.infinity, fit: BoxFit.cover),
          ),
          const SizedBox(height: 12),
        ],
        DropdownButtonFormField<String>(
          value: car.id,
          decoration: const InputDecoration(labelText: 'السيارة النشطة', border: OutlineInputBorder()),
          items: app.cars.map((c) => DropdownMenuItem(value: c.id, child: Text(c.displayName))).toList(),
          onChanged: (id) => id != null ? app.selectCar(id) : null,
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('حالة زيت المحرك', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                if (engLatest == null)
                  const Text('لم يتم تسجيل غيار زيت محرك بعد.')
                else ...[
                  Text('${engLatest.oilName} (${engLatest.viscosity})'),
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: ((car.currentOdometer - engLatest.odometer) / engLatest.rangeKm).clamp(0.0, 1.0),
                    minHeight: 10,
                  ),
                  const SizedBox(height: 6),
                  Text('الموعد القادم: ${engLatest.nextOdometer} كم (متبقي ${engLatest.nextOdometer - car.currentOdometer} كم)'),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('حالة زيت الفتيس', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 6),
                if (gbLatest == null)
                  const Text('لم يتم تسجيل غيار زيت فتيس بعد.')
                else
                  Text('${gbLatest.oilName} (${gbLatest.viscosity}) • القادم: ${gbLatest.nextOdometer} كم'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: odoCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'تحديث العداد الحالي (كم)', border: OutlineInputBorder()),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: () => _openCameraFor(odoCtrl, updateCarImmediately: true),
              icon: const Icon(Icons.camera_alt),
              tooltip: 'تصوير العداد',
            ),
            const SizedBox(width: 4),
            FilledButton(
              onPressed: () async {
                final v = int.tryParse(odoCtrl.text.trim());
                if (v != null) await app.updateOdometer(car.id, v);
              },
              child: const Text('تحديث'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildLogTab(AppProvider app, CarModel car) {
    final engSpecs = kEngineOilsDatabase[_oilBrand]?[_oilVisc] ?? [];
    final gbSpecs = kGearboxOilsDatabase[_gbType]?[_gbBrand] ?? [];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'engine', label: Text('زيت المحرك'), icon: Icon(Icons.water_drop)),
            ButtonSegment(value: 'gearbox', label: Text('زيت الفتيس'), icon: Icon(Icons.settings)),
          ],
          selected: {_logCategory},
          onSelectionChanged: (s) => setState(() {
            _logCategory = s.first;
            if (_logCategory == 'gearbox') {
              _rangeKmCtrl.text = '50000';
              _rangeMonths = 36;
            } else {
              _rangeKmCtrl.text = '10000';
              _rangeMonths = 12;
            }
          }),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _logOdoCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'قراءة العداد الحالية (كم)', border: OutlineInputBorder()),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: () => _openCameraFor(_logOdoCtrl),
              icon: const Icon(Icons.camera_alt),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (_logCategory == 'engine') ...[
          DropdownButtonFormField<String>(
            value: _oilBrand,
            isExpanded: true,
            decoration: const InputDecoration(labelText: '1. شركة الزيت'),
            items: kEngineOilsDatabase.keys.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
            onChanged: (v) => setState(() {
              _oilBrand = v!;
              _oilVisc = kEngineOilsDatabase[_oilBrand]!.keys.first;
              _oilSpecIdx = 0;
            }),
          ),
          DropdownButtonFormField<String>(
            value: _oilVisc,
            decoration: const InputDecoration(labelText: '2. اللزوجة'),
            items: kEngineOilsDatabase[_oilBrand]!.keys.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) => setState(() {
              _oilVisc = v!;
              _oilSpecIdx = 0;
            }),
          ),
          DropdownButtonFormField<int>(
            value: _oilSpecIdx.clamp(0, engSpecs.length - 1),
            isExpanded: true,
            decoration: const InputDecoration(labelText: '3. الفئة والمواصفات'),
            items: List.generate(engSpecs.length, (i) => DropdownMenuItem(value: i, child: Text(engSpecs[i].label))),
            onChanged: (i) => setState(() {
              _oilSpecIdx = i ?? 0;
              _rangeKmCtrl.text = engSpecs[_oilSpecIdx].rangeKm.toString();
              _rangeMonths = engSpecs[_oilSpecIdx].rangeMonths;
            }),
          ),
        ] else ...[
          DropdownButtonFormField<String>(
            value: _gbType,
            decoration: const InputDecoration(labelText: '1. نوع الفتيس'),
            items: kGearboxOilsDatabase.keys.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
            onChanged: (v) => setState(() {
              _gbType = v!;
              _gbBrand = kGearboxOilsDatabase[_gbType]!.keys.first;
              _gbSpecIdx = 0;
            }),
          ),
          DropdownButtonFormField<String>(
            value: _gbBrand,
            decoration: const InputDecoration(labelText: '2. الشركة'),
            items: kGearboxOilsDatabase[_gbType]!.keys.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
            onChanged: (v) => setState(() {
              _gbBrand = v!;
              _gbSpecIdx = 0;
            }),
          ),
          DropdownButtonFormField<int>(
            value: _gbSpecIdx.clamp(0, gbSpecs.length - 1),
            isExpanded: true,
            decoration: const InputDecoration(labelText: '3. المواصفات'),
            items: List.generate(gbSpecs.length, (i) => DropdownMenuItem(value: i, child: Text(gbSpecs[i].label))),
            onChanged: (i) => setState(() {
              _gbSpecIdx = i ?? 0;
              _rangeKmCtrl.text = gbSpecs[_gbSpecIdx].rangeKm.toString();
              _rangeMonths = gbSpecs[_gbSpecIdx].rangeMonths;
            }),
          ),
        ],
        TextField(controller: _extraSpecsCtrl, decoration: const InputDecoration(labelText: 'مواصفات خاصة / إضافات')),
        TextField(controller: _rangeKmCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المدى المتوقع (كم)')),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text('التاريخ والوقت: ${DateFormat('yyyy-MM-dd HH:mm').format(_selectedDateTime)}'),
          trailing: TextButton(
            onPressed: () async {
              final d = await showDatePicker(
                context: context,
                initialDate: _selectedDateTime,
                firstDate: DateTime(2000),
                lastDate: DateTime.now(),
              );
              if (d != null) setState(() => _selectedDateTime = d);
            },
            child: const Text('تغيير التاريخ'),
          ),
        ),
        CheckboxListTile(title: const Text('تغيير الفلتر'), value: _oilFilter, onChanged: (v) => setState(() => _oilFilter = v ?? true)),
        CheckboxListTile(title: const Text('تغيير فلتر الهواء'), value: _airFilter, onChanged: (v) => setState(() => _airFilter = v ?? false)),
        TextField(controller: _costCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'التكلفة (ج.م)')),
        TextField(controller: _centerCtrl, decoration: const InputDecoration(labelText: 'المركز / الميكانيكي')),
        TextField(controller: _notesCtrl, decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
        const SizedBox(height: 16),
        FilledButton.icon(
          icon: const Icon(Icons.check_circle),
          label: const Text('حفظ سجل تغيير الزيت'),
          onPressed: () async {
            final odo = int.tryParse(_logOdoCtrl.text.trim()) ?? car.currentOdometer;
            final rangeKm = int.tryParse(_rangeKmCtrl.text.trim()) ?? 10000;
            final log = OilLogModel(
              id: 'log_${DateTime.now().millisecondsSinceEpoch}',
              carId: car.id,
              category: _logCategory,
              odometer: odo,
              oilName: _logCategory == 'engine' ? _oilBrand : _gbBrand,
              viscosity: _logCategory == 'engine' ? _oilVisc : _gbType,
              specs: '${_logCategory == 'engine' ? engSpecs[_oilSpecIdx].label : gbSpecs[_gbSpecIdx].label} ${_extraSpecsCtrl.text.trim()}'.trim(),
              rangeKm: rangeKm,
              rangeMonths: _rangeMonths,
              nextOdometer: odo + rangeKm,
              dateTime: _selectedDateTime,
              oilFilter: _oilFilter,
              airFilter: _airFilter,
              cost: double.tryParse(_costCtrl.text.trim()) ?? 0,
              center: _centerCtrl.text.trim(),
              notes: _notesCtrl.text.trim(),
            );
            await app.addLog(log);
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم الحفظ! الموعد القادم عند ${log.nextOdometer} كم')));
              setState(() => _tabIndex = 0);
            }
          },
        ),
      ],
    );
  }

  Widget _buildHistoryTab(AppProvider app) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => _openAddCarDialog(context),
                icon: const Icon(Icons.add),
                label: const Text('إضافة سيارة'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _openReportDialog(context),
                icon: const Icon(Icons.description),
                label: const Text('تقرير شامل'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        const Text('سياراتي المسجلة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 6),
        ...app.cars.map((c) => Card(
              child: ListTile(
                leading: (c.photoPath != null && File(c.photoPath!).existsSync())
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(File(c.photoPath!), width: 44, height: 44, fit: BoxFit.cover),
                      )
                    : const CircleAvatar(child: Icon(Icons.directions_car)),
                title: Text(c.displayName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                subtitle: Text('العداد: ${c.currentOdometer} كم'),
                onTap: () => app.selectCar(c.id),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: 'إضافة / تغيير صورة السيارة',
                      icon: const Icon(Icons.add_a_photo_outlined),
                      onPressed: () async {
                        final p = await _pickCarPhoto(context);
                        if (p != null) await app.updateCarPhoto(c.id, p);
                      },
                    ),
                    IconButton(
                      tooltip: 'حذف السيارة',
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () => _confirmDeleteCar(app, c),
                    ),
                  ],
                ),
              ),
            )),
        const SizedBox(height: 14),
        const Text('سجل تغييرات الزيت', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 6),
        ...app.logs.map((l) => Card(
              child: ListTile(
                title: Text('${l.isGearbox ? "زيت فتيس" : "زيت محرك"} • ${l.oilName} (${l.viscosity})'),
                subtitle: Text('العداد: ${l.odometer} كم | القادم: ${l.nextOdometer} كم'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () => app.deleteLog(l.id),
                ),
              ),
            )),
      ],
    );
  }

  Widget _buildSettingsTab(AppProvider app, ThemeProvider themeProv) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.folder_open),
                title: const Text('حفظ نسخة احتياطية (مع الإعدادات والثيم)'),
                subtitle: const Text('يفتح متصفح الملفات لاختيار مكان الحفظ'),
                onTap: () async {
                  final path = await BackupService.exportBackup(app, themeProv);
                  if (mounted && path != null) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم الحفظ في: $path')));
                  }
                },
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.restore),
                title: const Text('استعادة البيانات والإعدادات'),
                onTap: () async {
                  final ok = await BackupService.importBackup(app, themeProv);
                  if (mounted && ok) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت استعادة البيانات والثيم بنجاح')));
                  }
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: const Icon(Icons.brush),
            title: const Text('تصميم ثيم مخصص'),
            subtitle: const Text('اختر ألوان الخط والأزرار والخلفية بحرية'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomThemeScreen())),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('تطبيق زيت — Android & iOS'),
            subtitle: Text('تصميم وإعداد: د/ محمد حماده'),
          ),
        ),
      ],
    );
  }
}
