import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class CustomThemeScreen extends StatefulWidget {
  const CustomThemeScreen({super.key});

  @override
  State<CustomThemeScreen> createState() => _CustomThemeScreenState();
}

class _CustomThemeScreenState extends State<CustomThemeScreen> {
  late Color headerBg, headerAccent, scaffoldBg, cardBg, textMain, textMuted, buttonBg, buttonText, navBg;

  @override
  void initState() {
    super.initState();
    final ct = context.read<ThemeProvider>().customPalette;
    headerBg = ct.headerBg;
    headerAccent = ct.headerAccent;
    scaffoldBg = ct.scaffoldBg;
    cardBg = ct.cardBg;
    textMain = ct.textMain;
    textMuted = ct.textMuted;
    buttonBg = ct.buttonBg;
    buttonText = ct.buttonText;
    navBg = ct.navBg;
  }

  void _pickColor(String title, Color current, ValueChanged<Color> onPicked) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: ColorPicker(pickerColor: current, onColorChanged: onPicked),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('تم')),
        ],
      ),
    );
  }

  Widget _tile(String label, Color color, ValueChanged<Color> onChanged) => ListTile(
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: CircleAvatar(backgroundColor: color),
        onTap: () => _pickColor(label, color, (c) => setState(() => onChanged(c))),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تصميم ثيم مخصص')),
      body: ListView(
        children: [
          _tile('لون الشريط العلوي', headerBg, (c) => headerBg = c),
          _tile('لون اسم التطبيق', headerAccent, (c) => headerAccent = c),
          _tile('لون الخلفية الرئيسية', scaffoldBg, (c) => scaffoldBg = c),
          _tile('لون خلفية البطاقات', cardBg, (c) => cardBg = c),
          _tile('لون الخط الرئيسي', textMain, (c) => textMain = c),
          _tile('لون الخط الثانوي', textMuted, (c) => textMuted = c),
          _tile('لون الأزرار', buttonBg, (c) => buttonBg = c),
          _tile('لون خط الأزرار', buttonText, (c) => buttonText = c),
          _tile('لون شريط التنقل السفلي', navBg, (c) => navBg = c),
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('حفظ وتطبيق الثيم المخصص'),
              onPressed: () async {
                final palette = ZeitThemePalette(
                  id: 'custom',
                  name: 'ثيم مخصص (تصميمك)',
                  headerBg: headerBg,
                  headerAccent: headerAccent,
                  scaffoldBg: scaffoldBg,
                  cardBg: cardBg,
                  textMain: textMain,
                  textMuted: textMuted,
                  buttonBg: buttonBg,
                  buttonText: buttonText,
                  navBg: navBg,
                  brightness: ThemeData.estimateBrightnessForColor(scaffoldBg),
                );
                await context.read<ThemeProvider>().updateCustomPalette(palette);
                if (mounted) Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
}
