import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

class CameraOcrScreen extends StatefulWidget {
  const CameraOcrScreen({super.key});

  @override
  State<CameraOcrScreen> createState() => _CameraOcrScreenState();
}

class _CameraOcrScreenState extends State<CameraOcrScreen> {
  final _picker = ImagePicker();
  final _odoCtrl = TextEditingController();
  File? _imageFile;
  bool _scanning = false;

  Future<void> _captureAndRecognize(ImageSource source) async {
    final picked = await _picker.pickImage(source: source, imageQuality: 85);
    if (picked == null) return;
    setState(() {
      _imageFile = File(picked.path);
      _scanning = true;
    });

    final inputImage = InputImage.fromFilePath(picked.path);
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final recognized = await recognizer.processImage(inputImage);
      final matches = RegExp(r'\d{4,7}').allMatches(recognized.text.replaceAll(',', '').replaceAll(' ', ''));
      if (matches.isNotEmpty) {
        final best = matches.map((m) => m.group(0)!).reduce((a, b) => a.length >= b.length ? a : b);
        _odoCtrl.text = best;
      }
    } finally {
      await recognizer.close();
      if (mounted) setState(() => _scanning = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قراءة العداد بالكاميرا (OCR)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: _imageFile == null
                    ? const Center(
                        child: Text(
                          'اضغط على "تصوير العداد" لتوجيه الكاميرا نحو أرقام الطبلون',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white70),
                        ),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Image.file(_imageFile!, fit: BoxFit.cover),
                      ),
              ),
            ),
            const SizedBox(height: 16),
            if (_scanning) const LinearProgressIndicator(),
            const SizedBox(height: 12),
            TextField(
              controller: _odoCtrl,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                labelText: 'الرقم المستخرج (تأكد منه أو عدّله)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _captureAndRecognize(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library),
                    label: const Text('من الاستوديو'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _captureAndRecognize(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('تصوير العداد'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  final val = int.tryParse(_odoCtrl.text.trim());
                  if (val != null) Navigator.pop(context, val);
                },
                child: const Text('اعتماد القراءة'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
