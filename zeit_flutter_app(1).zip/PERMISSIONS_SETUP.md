# إعداد الصلاحيات (Android & iOS)

## 1. Android (`android/app/src/main/AndroidManifest.xml`)
أضف الصلاحيات التالية قبل وسم `<application>`:
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

## 2. iOS (`ios/Runner/Info.plist`)
أضف المفاتيح التالية داخل `<dict>`:
```xml
<key>NSCameraUsageDescription</key>
<string>يحتاج تطبيق زيت إلى الكاميرا لتصوير وقراءة عداد الكيلومترات بالسيارة</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>يحتاج تطبيق زيت للوصول إلى الصور لاختيار صورة عداد السيارة</string>
<key>LSSupportsOpeningDocumentsInPlace</key>
<true/>
<key>UIFileSharingEnabled</key>
<true/>
```
